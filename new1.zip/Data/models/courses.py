from django.db import models


class Courses(models.Model):
    course_name = models.CharField(max_length=30)
    price=models.IntegerField(default=0)
    Time_duration=models.CharField(default=0,max_length=30)
    description = models.CharField(default='No Description',max_length=500)
    image = models.ImageField(upload_to='Pictures/courses/',default="No Image")

    def __str__(self):
        return self.course_name

    @staticmethod
    def get_all_courses():
        return Courses.objects.all()
