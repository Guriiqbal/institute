from django.db import models
from .courses import Courses

class Students(models.Model):
    regnumber = models.IntegerField(null=True)

    Name = models.CharField(max_length=30)
    DOB = models.CharField(max_length=30)
    gender=models.CharField(max_length=20)
    Father_name=models.CharField(max_length=30)
    Mother_name = models.CharField(max_length=30)
    Courses=models.CharField(max_length=30)
    Email=models.CharField(max_length=50)
    Contact=models.IntegerField(default=0)
    branch=models.CharField(max_length=50,default='Main Branch,Mandi Dabwali')
    Reffrence_name=models.CharField(max_length=30)
    Qualification=models.CharField(max_length=30)
    Address = models.CharField(max_length=500,default="Address Not Found")
    image=models.ImageField(upload_to='students/')

    def register(self):
        self.save()

    def IsExists(self):
        if Students.objects.filter(Email=self.Email, Contact=self.Contact):
            return True
        return False