from django.db import models


class Branch(models.Model):
    branch = models.CharField(max_length=30)

    def __str__(self):
        return self.branch

    @staticmethod
    def get_all_branchs():
        return Branch.objects.all()