from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.core.exceptions import ValidationError

from django.conf import settings
from .models.staff import Staff
from .models.courses import Courses
from .models.students import Students
from .models.branch import Branch
from django.core.mail import send_mail
from django.views.decorators.csrf import csrf_exempt
from .models import Subscriber
from django.db.models import Max

def subscribe(request):

    if request.method == 'POST':
        try:
            email = request.POST.get('newsletter_email')
            if email:
                Subscriber.objects.create(email=email)
                return redirect('homepage')  # Redirect to a thank you page after successful subscription
            else:
                # Handle invalid form submission
                return render(request, 'index.html', )
        except Exception as e:
            # Handle exceptions, such as database errors
            return render(request, 'index.html', { 'error_message': str(e)})
    return render(request, 'index.html', )


# Create your views here.
def index(request):
    courses = Courses.get_all_courses()[:3]
    if request.method == 'GET':
        return render(request, 'index.html',{'courses' :courses})
    else:
        postdata = request.POST
        Name = postdata.get("name")
        course =postdata.get("course")
        language =postdata.get("language")
        Email = postdata.get("email")

        Message = postdata.get("message")


        if not Name or not Email or not course or not language or not Message:
            return redirect("homepage")
        else:
            message_body = f"Name: {Name}\nEmail: {Email}\nLanguage: {language}\nCourse: {course}\nMessage: {Message}"
            try:
                # Send the email
                send_mail(
                    "Subject here",
                    message_body,
                    "iqbalsinghpb03@gmail.com",
                    ["iqbalsingh98147@gmail.com"],
                    fail_silently=False,
                )
            except ValidationError as e:
                # Handle validation errors
                error_message = str(e)
                print(error_message)
                return render(request, '404.html', {'error_message': error_message})
            except Exception as e:
                # Handle other exceptions
                error_message = "An error occurred while sending the email."
                print(error_message)
                return render(request, '404.html', {'error_message': error_message})

            return render(request, 'index.html',{'courses' :courses})
        #return render(request,'index.html')




def about(request):
    staff1 = Staff.get_all_staff_by_id(category_id=1)[:4]

    return render(request, 'about.html',{'staff1': staff1})

def features(request):
    return render(request,'feature.html')

def appointment(request):
    return render(request,'appointment.html')

def pageerror(request):
    return render(request,'404.html')

def courses(request):
    courses = Courses.get_all_courses()
    return render(request,'courses.html',{'courses' :courses})



def contact(request):
    if request.method == 'GET':
        return render(request, 'contact.html')
    else:
        postdata = request.POST
        Name = postdata.get("name")
        Email = postdata.get("email")
        Subject = postdata.get("subject")

        Message = postdata.get("message")


        if not Name or not Email or not Message or not Subject:
            return redirect("contact")
        else:
            message_body = f"Name: {Name}\nEmail: {Email}\nMessage: {Message}"
            try:
                # Send the email
                send_mail(
                    Subject,
                    message_body,
                    "iqbalsinghpb03@gmail.com",
                    ["iqbalsingh98147@gmail.com"],
                    fail_silently=False,
                )
            except ValidationError as e:
                # Handle validation errors
                error_message = str(e)
                print(error_message)
                return render(request, 'contact.html', {'error_message': error_message})
            except Exception as e:
                # Handle other exceptions
                error_message = "An error occurred while sending the email."
                print(error_message)
                return render(request, 'contact.html', {'error_message': error_message})

            return render(request, 'contact.html')

def team(request):
    staff1=Staff.get_all_staff_by_id(category_id=1)
    staff2 = Staff.get_all_staff_by_id(category_id=2)
    data={}
    data['staff1']=staff1
    data['staff2'] = staff2
    return render(request,'team.html',data)

def StudentRegistration(request):
    courses = Courses.get_all_courses()
    branchs=Branch.get_all_branchs()
    data = {}
    data['branchs'] = branchs
    data['courses'] = courses


    if Students.objects.count() == 0:
        regno = 20240001
    else:

        max_regnumber = Students.objects.aggregate(max=Max('regnumber'))['max']

        # Add 1 to the maximum registration number, or start at 1 if there are no existing records
        regno = max_regnumber + 1

    if request.method == 'GET':
        return render(request, 'studentregistration.html',data)
    else:
        postdata = request.POST
        Name = postdata.get("name")
        Contact = postdata.get("contact")

        Father_name = postdata.get("fathername")
        Mother_name = postdata.get("mothername")
        Qualification=postdata.get("qualification")
        Address = postdata.get("address")
        Gender=postdata.get("inlineRadioOptions")
        DOB = postdata.get("dob")
        Reffrence_by = postdata.get("reffrence")

        Course = postdata.get("course")
        Email = postdata.get("email")
        Image= request.FILES.get("image")

        values = {
            "name": Name,
            "contact": Contact,
            "fathername": Father_name,
            "mothername": Mother_name,
            "email": Email

        }
        errormessage = None
        print(regno)

        s1=Students(regnumber=regno,
                        Name=Name,
                        Contact=Contact,
                        Father_name=Father_name,
                        Mother_name=Mother_name,
                        Qualification=Qualification,
                        Address=Address,
                        gender=Gender,
                        DOB=DOB,
                        Reffrence_name=Reffrence_by,
                        Courses=Course,
                        Email=Email,
                        image=Image)


        if not Name and not Contact and not Email and not Father_name and not Mother_name and not Qualification and not Gender and not Reffrence_by and not Course:
            errormessage = "All Fields Are Required"
        elif not Name:
            errormessage = "Name is Required"
        elif not Contact:
            errormessage = "Contact Number Is Required"
        elif not Father_name:
            errormessage = "Father name is required"
        elif not Mother_name:
            errormessage = "Mother Name is required"
        elif not Qualification:
            errormessage = "Qualification is required"
        elif not Address:
            errormessage = "Address is required"
        elif not Gender:
            errormessage = "Gender is required"
        elif not Courses:
            errormessage = "Courses is required"
        elif not DOB:
            errormessage = "Date Of Birth is required"
        elif not Email:
            errormessage = "Email.is required"

        elif s1.IsExists():
            errormessage = "Email or Mobile Number Is Already Exists"


        if not errormessage:

            s1.save()
            return redirect('registration_success', regnumber=regno)
        else:
            data = {"error": errormessage,
                    "values": values}
            return render(request, 'studentregistration.html', data)

# views.py


# views.py
def RegistrationSuccess(request, regnumber):
    return render(request, 'registration_success.html', {'regnumber': regnumber})

