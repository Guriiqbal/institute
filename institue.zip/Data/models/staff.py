from django.db import models
from .courses import Courses
from .staff_category import Staff_Category
class Staff(models.Model):
    Staff_name = models.CharField(max_length=30)
    DOB = models.DateField()
    gender=models.CharField(max_length=20)
    Staff_Category=models.ForeignKey(Staff_Category,on_delete=models.CASCADE,default=1)
    Email=models.CharField(max_length=50)
    Contact=models.IntegerField(default=0)
    Qualification=models.CharField(max_length=30)
    course_trainer=models.ForeignKey(Courses,on_delete=models.CASCADE,default=1)
    image=models.ImageField(upload_to='students/')

    @staticmethod
    def get_all_staff():
        return Staff.objects.all()

    @staticmethod
    def get_all_staff_by_id(category_id):
        return Staff.objects.filter(Staff_Category=category_id)