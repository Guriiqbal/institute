from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models.staff import Staff
from .models.courses import Courses
from .models.students import Students
from django.core.mail import send_mail


# Create your views here.
def index(request):
    if request.method == 'GET':
        return render(request, 'index.html')
    else:
        postdata = request.POST
        Name = postdata.get("name")
        Email = postdata.get("email")
        Message = postdata.get("message")


        if not Name or not Email or not Message:
            return redirect("homepage")
        else:
            send_mail(
                "Subject here",
                Message,
                "iqbalsinghpb03@gmail.com",
                ["dhaliwalguri39@gmail.com"],
                fail_silently=False,
            )

            return render(request, 'index.html')

        #return render(request,'index.html')



def about(request):
    return render(request, 'about.html')

def courses(request):
    courses = Courses.get_all_courses()
    return render(request,'courses.html',{'courses' :courses})

def contact(request):
    return render(request,'contact.html')

def team(request):
    staff1=Staff.get_all_staff_by_id(category_id=1)
    staff2 = Staff.get_all_staff_by_id(category_id=2)
    data={}
    data['staff1']=staff1
    data['staff2'] = staff2
    return render(request,'team.html',data)

def StudentRegistration(request):
    if request.method == 'GET':
        return render(request, 'studentregistration.html')
    else:
        postdata = request.POST
        Name = postdata.get("name")
        Contact = postdata.get("contact")

        Father_name = postdata.get("fathername")
        Mother_name = postdata.get("mothername")
        Qualification=postdata.get("qualification")
        Address = postdata.get("address")
        Gender=postdata.get("inlineRadioOptions")
        DOB = postdata.get("dob")
        Reffrence_by = postdata.get("reffrence")

        Course = postdata.get("course")
        Email = postdata.get("email")
        Image=postdata.get("image")

        value = {
            "name": Name,
            "contact": Contact,
            "email": Email

        }
        errormessage = None

        s1=Students(Name=Name,
                        Contact=Contact,
                        Father_name=Father_name,
                        Mother_name=Mother_name,
                        Qualification=Qualification,
                        Address=Address,
                        gender=Gender,
                        DOB=DOB,
                        Reffrence_name=Reffrence_by,
                        Courses=Course,
                        Email=Email,
                        image=Image)


        if not Name and not Contact and not Email and not Father_name and not Mother_name and not Qualification and not Gender and not Reffrence_by and not Course:
            errormessage = "All Fields Are Required"
        elif not Name:
            errormessage = "Name is Required"
        elif not Contact:
            errormessage = "Contact Number Is Required"
        elif not Father_name:
            errormessage = "Father name is required"
        elif not Mother_name:
            errormessage = "Mother Name is required"
        elif not Qualification:
            errormessage = "Qualification is required"
        elif not Address:
            errormessage = "Address is required"
        elif not Gender:
            errormessage = "Gender is required"
        elif not Courses:
            errormessage = "Courses is required"
        elif not DOB:
            errormessage = "Date Of Birth is required"
        elif not Email:
            errormessage = "Email.is required"

        elif s1.IsExists():
            errormessage = "Email or Mobile Number Is Already Exists"


        if not errormessage:

            s1.register()
            return redirect("homepage")
        else:
            data = {"error": errormessage,
                    "values": value}
            return render(request, 'studentregistration.html', data)



