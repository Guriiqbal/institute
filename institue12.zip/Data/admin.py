from django.contrib import admin
from .models.students import Students
from .models.courses import Courses
from .models.staff import Staff
from .models.staff_category import Staff_Category
from .models.subscriber import Subscriber

admin.site.site_header = 'Unique Group Of Institutions'
admin.site.site_title = 'Unique Group Of Institutions-Admin Panel'
admin.site.index_title = 'Welcome To Unique Group Of Institutions'
class AdminStudent(admin.ModelAdmin):
    list_display = ['Name','DOB','gender','Father_name','Mother_name','Contact','Email','Courses','Reffrence_name','Qualification','Address','image']


class AdminCourse(admin.ModelAdmin):
    list_display = ['course_name','price','Time_duration','description']

class AdminStaff(admin.ModelAdmin):
    list_display = ['Staff_name','DOB','gender','Staff_Category','Contact','Email','course_trainer','Qualification','image']


class AdminStaffCategory(admin.ModelAdmin):
    list_display = ['Category']

class AdminSubscribe(admin.ModelAdmin):
    list_display = ['email']

admin.site.register(Students,AdminStudent)
admin.site.register(Courses,AdminCourse)

admin.site.register(Staff,AdminStaff)
admin.site.register(Staff_Category,AdminStaffCategory)
admin.site.register(Subscriber,AdminSubscribe)


